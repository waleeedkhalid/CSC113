package com.csc113.project;

public class PetException extends Exception {
	public PetException(String message) {
        super(message);
    }
}
